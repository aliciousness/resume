# MY RESUME

This is my resume website hosted on s3 with cloudfront. The infrastucture for the wesbite is built on another repository with pulumi https://github.com/aliciousness/new_website
